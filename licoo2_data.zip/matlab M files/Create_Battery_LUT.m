Battery.Em_LUT = [Em_neg5 Em_2 Em_12 Em_20];
Battery.R0_LUT = [R0_neg5 R0_2 R0_12 R0_20];
Battery.R1_LUT = [R1_neg5 R1_2 R1_12 R1_20];
Battery.C1_LUT = [C1_neg5 C1_2 C1_12 C1_20];


% Battery.Em_LUT = [Em_neg5 Em_2 Em_20];
% Battery.R0_LUT = [R0_neg5 R0_2 R0_20];
% Battery.R1_LUT = [R1_neg5 R1_2 R1_20];
% Battery.C1_LUT = [C1_neg5 C1_2 C1_20];