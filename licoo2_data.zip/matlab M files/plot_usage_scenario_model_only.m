%close all;

%create time, current, voltage, temp, power arrays for plotting
arrTime1 = arrTime(1:Length_Time);
mod_current = interp1(arrt, arrC, arrTime1)';
Model_Voltage1 = Model_Voltage(1:Length_Time);
Model_Temp1 = Model_Temp(1:Length_Time);
model_power = mod_current .* Model_Voltage1;

   
figure('Name','In-Use Scenario','NumberTitle','off');
set(gcf, 'units','inches','outerposition',[0 0 6.5 8]);

subplot(4,1,1);
plot(arrt, arrC.*-1);
%legend('Cell Current');
xticks([300:300:4800])
xticklabels({ })
xlim([0 Length_Time]);
ax = gca;
ax.YGrid = 'on';
ylabel('Cell Current (A)');
title('Scenario 2 - Stored Inside, Insulated','FontSize',16);



subplot(4,1,2);
%arrTime1 = arrTime(1:Length_Time);
%arrV1 = arrV(1:Length_Time);            
%plot(arrTime1, arrV1); hold on;         %measured voltage
%Model_Voltage1 = Model_Voltage(1:Length_Time);
plot(arrTime1, Model_Voltage1);         %modeled voltage
ylim([2 4.2]);
%legend('Measured', 'Modeled','Location','south');
xticks([300:300:4800])
xticklabels({ })
xlim([0 Length_Time]);
ax = gca;
ax.YGrid = 'on';
ylabel('Cell Voltage (V)');

subplot(4,1,3);
plot(arrt, arrTemp); hold on; %ambient
%Model_Temp1 = Model_Temp(1:Length_Time);
plot(arrTime1, Model_Temp1); %modeled
%arrLabTemp1 = arrLabTemp(1:Length_Time);
%plot(arrTime1, arrLabTemp1); %measured
%legend('Ambient', 'Modeled', 'Measured', 'Location','north');
legend('Ambient', 'Cell', 'Location','north');
xticks([300:300:4800])
xticklabels({ })
xlim([0 Length_Time]);
ylim([-20 20]);
ax = gca;
ax.YGrid = 'on';
ylabel('Temp (\circC)');

subplot(4,1,4);
SOC1 = SOC(1:Length_Time);
plot(arrTime1, SOC1);
ylim([0 1]);
%legend('SOC');
ax = gca;
ax.YGrid = 'on';
ylabel('SOC');

% subplot(5,1,5);
% plot(arrt, elevation);
% xticks([300:300:4800])
% xticklabels({ })
% xlim([0 Length_Time]);
% ax = gca;
% ax.YGrid = 'on';
% ylabel('Elevation (m)');

%xticks([300, 600, 900, 1200, 1500, 1800, 2100, 2400])
xticks([300:300:4800])
xticklabels({'0:05', '0:10', '0:15', '0:20', '0:25', '0:30', '0:35',...
    '0:40','0:45','0:50','0:55','1:00','1:05','1:10','1:15','1:20',...
    '1:25'})
xtickangle(60)
xlim([0 Length_Time]);
xlabel('Time (H:MM)');

wattHours = sum(model_power)/-3600 %display total watt-hours of run

saveas(gcf, 'scenario2-inside-insulated', 'emf')
%print('validation_response2', '-dpng', '-r300', '-painters') 

