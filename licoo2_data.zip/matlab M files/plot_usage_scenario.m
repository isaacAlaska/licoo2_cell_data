close all;

   
figure('Name','In-Use Scenario','NumberTitle','off');
set(gcf, 'units','inches','outerposition',[0 0 6.5 8]);

subplot(5,1,1);
plot(arrt, arrC);
%legend('Cell Current');
xticks([300, 600, 900, 1200, 1500, 1800, 2100, 2400])
xticklabels({ })
xlim([0 Length_Time]);
ax = gca;
ax.YGrid = 'on';
ylabel('Cell Current (A)');
title('In-Use Scenario','FontSize',16);

subplot(5,1,2);
plot(arrt, elevation);
xticks([300, 600, 900, 1200, 1500, 1800, 2100, 2400])
xticklabels({ })
xlim([0 Length_Time]);
ax = gca;
ax.YGrid = 'on';
ylabel('Elevation (m)');

subplot(5,1,3);
arrTime1 = arrTime(1:Length_Time);
arrV1 = arrV(1:Length_Time);            
plot(arrTime1, arrV1); hold on;         %measured voltage
Model_Voltage1 = Model_Voltage(1:Length_Time);
plot(arrTime1, Model_Voltage1);         %modeled voltage
ylim([2 4.2]);
legend('Measured', 'Modeled','Location','south');
xticks([300, 600, 900, 1200, 1500, 1800, 2100, 2400])
xticklabels({ })
xlim([0 Length_Time]);
ax = gca;
ax.YGrid = 'on';
ylabel('Cell Voltage (V)');

subplot(5,1,4);
plot(arrt, arrTemp); hold on; %ambient
Model_Temp1 = Model_Temp(1:Length_Time);
plot(arrTime1, Model_Temp1); %modeled
arrLabTemp1 = arrLabTemp(1:Length_Time);
plot(arrTime1, arrLabTemp1);
legend('Ambient', 'Modeled', 'Measured', 'Location','north');
xticks([300, 600, 900, 1200, 1500, 1800, 2100, 2400])
xticklabels({ })
xlim([0 Length_Time]);
ylim([-20 20]);
ax = gca;
ax.YGrid = 'on';
ylabel('Temp (\circC)');

subplot(5,1,5);
SOC1 = SOC(1:Length_Time);
plot(arrTime1, SOC1);
ylim([0 1]);
%legend('SOC');
ax = gca;
ax.YGrid = 'on';
ylabel('SOC');

xticks([300, 600, 900, 1200, 1500, 1800, 2100, 2400])
xticklabels({'0:05', '0:10', '0:15', '0:20', '0:25', '0:30', '0:35',...
    '0:40'})
xtickangle(60)
xlim([0 Length_Time]);
xlabel('Time (H:MM)');

saveas(gcf, 'In-Use Scenario', 'emf')
%print('validation_response2', '-dpng', '-r300', '-painters') 

