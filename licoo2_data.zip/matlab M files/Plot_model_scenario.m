close all;

   
figure('Name','Validation Response','NumberTitle','off');
set(gcf, 'units','inches','outerposition',[0 0 6.5 7]);

subplot(4,1,1);
invCurrent = arrC .* (-1);
plot(arrt, invCurrent);
%legend('Cell Current');
xticks([900, 1800, 2700, 3600, 4500, 5400, 6300, 7200, 8100, 9000, 9900])
xticklabels({ })
xlim([0 length(arrt)]);
ax = gca;
ax.YGrid = 'on';
ylabel('Cell Current (A)');
title('Parameter Validation at -20 \circC','FontSize',16);

subplot(4,1,2);
yyaxis left
arrV1 = arrV(1:Length_Time);
plot(arrt, arrV1,'r'); hold on;     %measured voltage
Model_Voltage1 = Model_Voltage(1:Length_Time);
plot(arrt, Model_Voltage1,'b');     %model voltage
ylim([2 4.2]);
ylabel('Cell Voltage (V)','color','k');
yyaxis right
Pdif = (abs(Model_Voltage1 - arrV1) ./ arrV1) * 100;
plot(arrt, Pdif,'m')
legend('Measured', 'Modeled','Error','Location','south');
ylabel('Difference (%)','color','k');
xticks([900, 1800, 2700, 3600, 4500, 5400, 6300, 7200, 8100, 9000, 9900])
xticklabels({ })
xlim([0 length(arrt)]);
ax = gca;
ax.YGrid = 'on';


subplot(4,1,3);
plot(arrt, ones(Length_Time,1)*Average_Temp); hold on;  %ambient
%plot(arrt, arrTemp);                %measured
Model_Temp = Model_Temp(1:Length_Time);
plot(arrt, Model_Temp);             %modeled
%legend('Ambient', 'Measured', 'Modeled','Location','north');
legend('Ambient','Modeled','Location','north');
xticks([900, 1800, 2700, 3600, 4500, 5400, 6300, 7200, 8100, 9000, 9900])
xticklabels({ })
xlim([0 length(arrt)]);
ax = gca;
ax.YGrid = 'on';
ylabel('Temp (\circC)');

subplot(4,1,4);
SOC = SOC(1:Length_Time);
plot(arrt, SOC);
ylim([0 1]);
%legend('SOC');
ax = gca;
ax.YGrid = 'on';
ylabel('SOC');

xticks([900, 1800, 2700, 3600, 4500, 5400, 6300, 7200, 8100, 9000, 9900])
xticklabels({'0:15', '0:30', '0:45', '1:00', '1:15', '1:30', '1:45',...
    '2:00', '2:15', '2:30', '2:45'})
xtickangle(60)
xlim([0 length(arrt)]);
xlabel('Time (H:MM)');

%saveas(gcf, 'Validation_response-20C_1800ma', 'emf')
%print('validation_response2', '-dpng', '-r300', '-painters') 

