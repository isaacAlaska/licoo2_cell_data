fileName = '1800mah_10C.xlsx';
arrV = xlsread(fileName, 'D17:D11000');
arrC = xlsread(fileName, 'F17:F11000');
arrt = xlsread(fileName, 'B17:B11000');
arrTemp = xlsread(fileName, 'G17:G11000');

ColdChamberData = struct('MyVoltage', arrV, 'MyCurrent', arrC, 'MyTime', arrt, 'MyTemp', arrTemp);

Battery_Current = [arrt, arrC];
Battery_Voltage = [arrt, arrV];
Battery_Temp = [arrt, arrTemp];