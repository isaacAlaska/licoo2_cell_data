%temp_breakpoints = [-10 -5 2 12 20]; %be sure these match the LUT break points
temp_breakpoints = Battery.Temperature_LUT -273.15;

Battery.Em_LUT = [Em_neg20 Em_neg10 Em_neg5 Em_2 Em_12 Em_20];
Battery.R0_LUT = [R0_neg20 R0_neg10 R0_neg5 R0_2 R0_12 R0_20];
Battery.R1_LUT = [R1_neg20 R1_neg10 R1_neg5 R1_2 R1_12 R1_20];
Battery.C1_LUT = [C1_neg20 C1_neg10 C1_neg5 C1_2 C1_12 C1_20];

close all;

figure('Name','R0 vs temp','NumberTitle','off');


set(axes,'LineStyleOrder',{'-','--',':','-.'}')  %create axes with respective LineStyleOrder
hold on
 
plot(temp_breakpoints, Battery.R0_LUT)
legend('SOC 0', 'SOC .1','SOC .2','SOC .3','SOC .4','SOC .5','SOC .6','SOC .7','SOC .8','SOC .9','SOC 1')
xlabel('Temperature (\circC)')
ylabel('R0 Resistance (\Omega)')
title('R0 vs. Temperature at Various SOCs')
movegui([1,-1]);




figure('Name','Em vs temp','NumberTitle','off');

set(axes,'LineStyleOrder',{'-','--',':','-.'}')  %create axes with respective LineStyleOrder
hold on

plot(temp_breakpoints, Battery.Em_LUT)
legend('SOC 0', 'SOC .1','SOC .2','SOC .3','SOC .4','SOC .5','SOC .6','SOC .7','SOC .8','SOC .9','SOC 1')
xlabel('Temperature (\circC)')
ylabel('Voltage (V)')
title('Em vs. Temperature at Various SOCs')
movegui([580,-1]);


figure('Name','R1 vs temp','NumberTitle','off');

set(axes,'LineStyleOrder',{'-','--',':','-.'}')  %create axes with respective LineStyleOrder
hold on

plot(temp_breakpoints, Battery.R1_LUT)
legend('SOC 0', 'SOC .1','SOC .2','SOC .3','SOC .4','SOC .5','SOC .6','SOC .7','SOC .8','SOC .9','SOC 1')
xlabel('Temperature (\circC)')
ylabel('R1 Resistance (\Omega)')
title('R1 vs. Temperature at Various SOCs')
movegui([1,-500]);

figure('Name','C1 vs temp','NumberTitle','off');

set(axes,'LineStyleOrder',{'-','--',':','-.'}')  %create axes with respective LineStyleOrder
hold on

plot(temp_breakpoints, Battery.C1_LUT)
legend('SOC 0', 'SOC .1','SOC .2','SOC .3','SOC .4','SOC .5','SOC .6','SOC .7','SOC .8','SOC .9','SOC 1')
xlabel('Temperature (\circC)')
ylabel('Capacitance (F)')
title('C1 vs. Temperature at Various SOCs')
movegui([580,-500]);

%

figure('Name','tau vs temp','NumberTitle','off');

set(axes,'LineStyleOrder',{'-','--',':','-.'}')  %create axes with respective LineStyleOrder
hold on

tauNum = ones([11,6]);
tauDenom = times(Battery.R1_LUT, Battery.C1_LUT);

tau = rdivide(tauNum,tauDenom);

tau2 = tau([2:end],:); %eliminate the first row at SOC = 0




% plot(temp_breakpoints, tau)

%plot(tau(2:11,1:5)') %plot only rows 2 through 11, and columns 1 through 5

plot(temp_breakpoints, tau2)

% legend('SOC 0', 'SOC .1','SOC .2','SOC .3','SOC .4','SOC .5','SOC .6','SOC .7','SOC .8','SOC .9','SOC 1')
legend('SOC .1','SOC .2','SOC .3','SOC .4','SOC .5','SOC .6','SOC .7','SOC .8','SOC .9','SOC 1')
xlabel('Temperature (\circC)')
ylabel('Time constant (S)')
title('R1C1 Time Constant vs. Temperature at Various SOCs')
movegui([1160,-1]);
