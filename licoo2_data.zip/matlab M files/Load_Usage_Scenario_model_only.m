%loads scenario data
fileName = 'Usage_Scenario_3.xlsx';
arrC = xlsread(fileName, 'J2:J100');
arrt = xlsread(fileName, 'D2:D100');
arrTemp = xlsread(fileName, 'G2:G100');
elevation = xlsread(fileName, 'N2:N100');

UsageScenarioData = struct('MyCurrent', arrC, 'MyTime', arrt, 'MyTemp', arrTemp);

Battery_Current = [arrt, arrC];
Ambient_Temp = [arrt, arrTemp];

%loads lab validation data
% fileName2 = 'Usage_Scenario_2_lab_data.xlsx';
% 
% arrV        = xlsread(fileName2, 'D15:D10000');
% arrTime     = xlsread(fileName2, 'B15:B10000');
% arrLabTemp  = xlsread(fileName2, 'G15:G10000');
% Battery_Temp = [arrTime, arrLabTemp];
% Battery_Voltage = [arrTime, arrV];

arrTime = 1:1:20000; %define a time array that increments by 1 second intervals
Length_Time = arrt(length(arrt));

Battery.T_init = arrTemp(1) + 273.15; %K

%% Thermal Properties

% Cell dimensions and sizes
cell_thickness = 0.025; %m
cell_width = 0.1; %m
cell_height = 0.035; %m

% Cell surface area
cell_area = 2 * (...
    cell_thickness * cell_width +...
    cell_thickness * cell_height +...
    cell_width * cell_height); %m^2

% Cell volume
cell_volume = cell_thickness * cell_width * cell_height; %m^3

% Cell mass
Battery.cell_mass = .165; %kg


% Volumetric heat capacity
% assumes uniform heat capacity throughout the cell
% ref: J. Electrochemical Society 158 (8) A955-A969 (2011) pA962
cell_rho_Cp = 2.04E6; %J/m3/K

%cell_rho_Cp = 11.04E6; %J/m3/K (working value without compensating for mass)

% Specific Heat
% Specific heat should be close to 1000 J/kg/K
% ref: J. Electrochemical Society 146 (3) 947-954 (1999)
%Battery.cell_Cp_heat = cell_rho_Cp * cell_volume; %J/kg/K (this doesn't account for mass, units are wrong)
Battery.cell_Cp_heat = cell_rho_Cp * cell_volume / Battery.cell_mass; %J/kg/K

% Convective heat transfer coefficient
% For natural convection this number should be in the range of 5 to 25
h_conv = 15; %W/m^2/K
h_conv = .547; %assuming battery U value of 15, and 2" of R-10 foam
%h_conv_end = 16; %W/m^2/K
h_conv_end = h_conv;