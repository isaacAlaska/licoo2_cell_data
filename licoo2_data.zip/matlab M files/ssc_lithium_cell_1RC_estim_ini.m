% Initialization file for demo ssc_lithium_cell_1RC_estim_ini.mdl. Demo
% based on T. Huria, M. Ceraolo, J. Gazzarri, R. Jackey. "High Fidelity
% Electrical Model with Thermal Dependence for Characterization and
% Simulation of High Power Lithium Battery Cells," IEEE International
% Electric Vehicle Conference, March 2012
%
% Copyright 2012 The MathWorks, Inc.


%% Chosen Values

% SOC Lookup Table breakpoints
SOC_LUT = (0:0.1:1)';


%% Known Values

% Battery capacity
% Measured by coulomb counting the discharge curve
Capacity = 1.7500; %Ampere*hours

% Charge deficit at start of data set
% Assumption based on preparation of test
Qe_init = 0; %Ampere*hours


%% Estimated Parameters - Initial starting points before estimation

% Em open-circuit voltage vs SOC
%Em = 3.8*ones(size(SOC_LUT)); %Volts
Em = [3.3806;3.6994;3.7378;3.772;3.8064;3.839;3.882;3.9375;4.019;4.1229;4.1653]

% R0 resistance vs SOC
%R0 = 0.01*ones(size(SOC_LUT)); %Ohms
R0 = [0.0089997;0.010991;0.0097115;0.010248;0.010167;0.010076;0.01015;0.010083;0.010151;0.010214;0.0093269]

% R1 Resistance vs SOC
%R1 = 0.005*ones(size(SOC_LUT)); %Ohms
R1 = [0.0099135;0.0020863;0.0048432;0.0046293;0.0048177;0.004853;0.0047618;0.0047169;0.005461;0.0045467;0.0053835]

% C1 Capacitance vs SOC
%C1 = 10000*ones(size(SOC_LUT)); %Farads
C1 = [14.35;19585;8624;10950;10323;9970.3;10436;10555;9689;11201;10070]


%% Load Dataset
load('LiBatt_PulseData.mat')

        