% Initialization file for demo ssc_lithium_cell_1RC.mdl. Demo
% based on T. Huria, M. Ceraolo, J. Gazzarri, R. Jackey. "High Fidelity
% Electrical Model with Thermal Dependence for Characterization and
% Simulation of High Power Lithium Battery Cells," IEEE International
% Electric Vehicle Conference, March 2012
%
% Copyright 2012 The MathWorks, Inc.


fileName = '1800mah_2C.xlsx';
arrV = xlsread(fileName, 'D17:D11000');
arrC = xlsread(fileName, 'F17:F11000');
arrt = xlsread(fileName, 'B17:B11000');
arrTemp = xlsread(fileName, 'G17:G11000');

ColdChamberData = struct('MyVoltage', arrV, 'MyCurrent', arrC, 'MyTime', arrt, 'MyTemp', arrTemp);

Battery_Current = [arrt, arrC];
Battery_Voltage = [arrt, arrV];
Battery_Temp = [arrt, arrTemp];

Length_Time = length(arrt);

Average_Temp = mean(arrTemp);
Ambient_Temp = [arrt, ones(Length_Time,1)*Average_Temp];


%% Lookup Table Breakpoints

%Battery.SOC_LUT = [0 0.1 0.25 0.5 0.75 0.9 1]';
Battery.SOC_LUT = [0:0.1:1]';
Battery.Temperature_LUT = [-20 -10.39 -5.79 .604 11.10 18.8] + 273.15;

%% Em Branch Properties (OCV, Capacity)

% Battery capacity
Battery.Capacity_LUT = [
    %28.0081   27.6250   27.6392]; %Ampere*hours
    %1.750 1.800   1.800   1.800 1.800]; %Ampere*hours
    1.6 1.6 1.7   1.75   1.800 1.800]; %Ampere*hours
% Em open-circuit voltage vs SOC rows and T columns
% Battery.Em_LUT = [
%     1.0000    1.0000    1.0000
%     1.0000    1.0000    1.0000
%     1.0000    1.0000    1.0000
%     1.0000    1.0000    1.0000
%     3.4966    3.3806    3.5148      
%     3.5519    3.6994    3.5653      
%     3.6183    3.7500    3.6402      
%     3.7066    3.8390    3.7213      
%     3.9131    4.0000    3.9376      
%     4.0748    4.1229    4.0821      %.9 soc
%     4.1923    4.1653    4.1930];    %1 soc      (all in Volts)
   

Battery.Em_LUT = [Em_neg20 Em_neg10 Em_neg5 Em_2 Em_12 Em_20];

%% Terminal Resistance Properties

% R0 resistance vs SOC rows and T columns
% Battery.R0_LUT = [
%     1.0000    1.0000    1.0000
%     1.0000    1.0000    1.0000
%     1.0000    1.0000    1.0000
%     1.0000    1.0000    1.0000
%     0.0117    0.0090    0.0090
%     0.0110    0.0110    0.0090
%     0.0114    0.0099    0.0092
%     0.0107    0.0101    0.0088
%     0.0107    0.0101    0.0091
%     0.0113    0.0102    0.0089
%     0.0116    0.0093    0.0089]; %Ohms

Battery.R0_LUT = [R0_neg20 R0_neg10 R0_neg5 R0_2 R0_12 R0_20];

%% RC Branch 1 Properties

% R1 Resistance vs SOC rows and T columns
% Battery.R1_LUT = [
%     1.0000    1.0000    1.0000
%     1.0000    1.0000    1.0000
%     1.0000    1.0000    1.0000
%     1.0000    1.0000    1.0000
%     0.0109    0.0099    0.0013
%     0.0069    0.0021    0.0012
%     0.0047    0.0047    0.0013
%     0.0034    0.0049    0.0010
%     0.0033    0.0051    0.0014
%     0.0033    0.0045    0.0011
%     0.0028    0.0054    0.0011]; %Ohms

Battery.R1_LUT = [R1_neg20 R1_neg10 R1_neg5 R1_2 R1_12 R1_20];

% C1 Capacitance vs SOC rows and T columns
% Battery.C1_LUT = [
%     1.0000    1.0000    1.0000
%     1.0000    1.0000    1.0000
%     1.0000    1.0000    1.0000
%     1.0000    1.0000    1.0000
%     1913.6    6.351    30609
%     4625.7    19603    32995
%     23306     09000    47535
%     10736     09970    26325
%     18036     09800    48274
%     12251     11205    26839
%     9022.9    10070    30606]; %Farads

Battery.C1_LUT = [C1_neg20 C1_neg10 C1_neg5 C1_2 C1_12 C1_20];

   
%% Thermal Properties

% Cell dimensions and sizes
cell_thickness = 0.025; %m
cell_width = 0.1; %m
cell_height = 0.035; %m

% Cell surface area
cell_area = 2 * (...
    cell_thickness * cell_width +...
    cell_thickness * cell_height +...
    cell_width * cell_height); %m^2

% Cell volume
cell_volume = cell_thickness * cell_width * cell_height; %m^3

% Cell mass
Battery.cell_mass = .165; %kg

% Volumetric heat capacity
% assumes uniform heat capacity throughout the cell
% ref: J. Electrochemical Society 158 (8) A955-A969 (2011) pA962
cell_rho_Cp = 2.04E6; %J/m3/K

% Specific Heat
Battery.cell_Cp_heat = cell_rho_Cp * cell_volume; %J/kg/K

% Convective heat transfer coefficient
% For natural convection this number should be in the range of 5 to 25
h_conv = 5; %W/m^2/K
h_conv_end = 5; %W/m^2/K

%% Initial Conditions

% Charge deficit
Battery.Qe_init = 0; %Ampere*hours

% Ambient Temperature
%Battery.T_init = arrTemp(1) + 273.15; %K
Battery.T_init = Average_Temp(1) + 273.15; %K

%run('Create_Battery_LUT.m');


