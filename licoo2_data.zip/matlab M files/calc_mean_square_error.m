len = length(arrV);
Compare_Voltage = Model_Voltage(1:len);
Err = immse(arrV, Compare_Voltage);
fprintf('\n Heat loss value is %0.6f\n', h_conv);
fprintf(' And the mean-squared error is %0.6f\n', Err);