Battery.Em_LUT = [Em_neg20 Em_neg10 Em_neg5 Em_2 Em_12 Em_20];
Battery.R0_LUT = [R0_neg20 R0_neg10 R0_neg5 R0_2 R0_12 R0_20];
Battery.R1_LUT = [R1_neg20 R1_neg10 R1_neg5 R1_2 R1_12 R1_20];
Battery.C1_LUT = [C1_neg20 C1_neg10 C1_neg5 C1_2 C1_12 C1_20];

xlswrite('LUT_Params.xlsx', {'Em'},1, 'B1');
xlswrite('LUT_Params.xlsx', Battery.Em_LUT,1, 'B3');

xlswrite('LUT_Params.xlsx', {'R0'},1, 'J1');
xlswrite('LUT_Params.xlsx', Battery.R0_LUT,1, 'J3');

xlswrite('LUT_Params.xlsx', {'R1'},1, 'R1');
xlswrite('LUT_Params.xlsx', Battery.R1_LUT,1, 'R3');

xlswrite('LUT_Params.xlsx', {'C1'},1, 'Z1');
xlswrite('LUT_Params.xlsx', Battery.C1_LUT,1, 'Z3');