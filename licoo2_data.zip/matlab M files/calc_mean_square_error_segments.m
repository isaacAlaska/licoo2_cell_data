close all;

len = length(arrV);
Compare_Voltage = Model_Voltage(1:len);

Tsoc80 = find((SOC < 0.8),1);   %first time value where soc < 0.8

Tsoc20 = find((SOC < 0.2),1);   %first time value where soc < 0.2

arrV_initial = arrV(1:Tsoc80);
arrV_mid = arrV(Tsoc80:Tsoc20);
arrV_end = arrV(Tsoc20:len);

Compare_V_initial = Compare_Voltage(1:Tsoc80);
Compare_V_mid = Compare_Voltage(Tsoc80:Tsoc20);
Compare_V_end = Compare_Voltage(Tsoc20:len);

Err_initial = immse(arrV_initial, Compare_V_initial);
Err_mid = immse(arrV_mid, Compare_V_mid);
Err_end = immse(arrV_end, Compare_V_end);
fprintf('\n Heat loss value is %0.6f\n', h_conv);
fprintf('\n Ambient temp is %0.6f\n', Average_Temp);
fprintf(' The mean-squared error from SOC 1 to SOC 0.8 is %0.6f\n', Err_initial);
fprintf(' The mean-squared error from SOC 0.8 to SOC 0.2 is %0.6f\n', Err_mid);
fprintf(' The mean-squared error from SOC 0.2 to SOC 0 is %0.6f\n', Err_end);

%store values in error table
if Average_Temp > 10 
    MSE_Matrix(1, 1) = Err_initial;
    MSE_Matrix(1, 2) = Err_mid;
    MSE_Matrix(1, 3) = Err_end;
end
if 10 > Average_Temp > -10
    MSE_Matrix(2, 1) = Err_initial;
    MSE_Matrix(2, 2) = Err_mid;
    MSE_Matrix(2, 3) = Err_end;
end
if -10 > Average_Temp
    MSE_Matrix(3, 1) = Err_initial;
    MSE_Matrix(3, 2) = Err_mid;
    MSE_Matrix(3, 3) = Err_end;
end

% uf = uifigure;
% t = uitable(uf, 'Data',MSE_Matrix)
% t.ColumnName = {'SOC > 0.8','0.8 > SOC > 0.2','0.2 > SOC'};
% t.RowName = {'20 *C','2 *C','-20 *C'};
% t.Position = [20 20 325 90];

rowNames = {'20 degrees C','2 degrees C','-20 degrees C'};
colNames = {'First','Mid','Last'};
sTable = array2table(MSE_Matrix,'RowNames',rowNames,'VariableNames',colNames)


%enable this line to write new data to excel table
%xlswrite('mean_standard_error.xlsx', MSE_Matrix,1, 'B3');













