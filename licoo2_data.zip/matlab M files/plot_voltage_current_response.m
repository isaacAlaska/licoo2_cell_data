close all;

figure('Name','cell_voltage_response','NumberTitle','off');

yyaxis left
plot(arrt, arrV);
ylim([2 4.2]);
ylabel('Cell Voltage (V)');


invCurrent = arrC .* (-1);

yyaxis right
plot(arrt, invCurrent);
ylabel('Current Leaving Cell (A)');
ylim([0 1]);

xticks([900, 1800, 2700, 3600, 4500, 5400, 6300, 7200, 8100, 9000, 9900])
xticklabels({'0:15', '0:30', '0:45', '1:00', '1:15', '1:30', '1:45',...
    '2:00', '2:15', '2:30', '2:45'})
xtickangle(60)
xlim([0 length(arrt)]);
xlabel('Time (H:MM)');

title('Voltage and Current During 0.9 A Pulse Discharge at -20 \circC','FontSize',16)
legend('Cell Voltage','Current', 'Location','southwest')