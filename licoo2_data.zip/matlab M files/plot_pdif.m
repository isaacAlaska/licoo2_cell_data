%Ambient_Temp = [arrt, ones(Length_Time,1)*Average_Temp];
Model_Voltage1 = ones(Length_Time,1)*4;

Pdif = (abs(Model_Voltage1 - arrV1) ./ arrV1) * 100;

figure
plot(arrt, Pdif)